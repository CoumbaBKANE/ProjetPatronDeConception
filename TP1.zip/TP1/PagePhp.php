<?php
// Récupération du nom d'utilisateur et du mot de passe envoyés par le code Java
$username = $_POST['username'];
$password = $_POST['password'];

// Vérification du nom d'utilisateur et du mot de passe
if ($username == "monlogin" && $password == "passe") {
    // Authentification réussie
    echo "0"; // Code d'erreur 0 pour succès
} else {
    // Authentification échouée
    echo "1"; // Code d'erreur 1 pour échec
}
?>
